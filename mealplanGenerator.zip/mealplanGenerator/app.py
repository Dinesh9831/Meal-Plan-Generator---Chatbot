
from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Your Gemini API key
GEMINI_API_KEY = 'AIzaSyDXQJitj0B5xoxm2daf_OHNxewRyPeffmo'
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_meal():
    carbs = request.form.get('carbs')
    protein = request.form.get('protein')
    fat = request.form.get('fat')
    calories = request.form.get('calories')
    meal_type = request.form.get('meal_type')
    cuisine_type = request.form.get('cuisine_type')

    # Build prompt based on selected values
    prompt = f"Create a meal with {carbs}g carbs, {protein}g protein, {fat}g fat, and {calories} calories."
    if meal_type and meal_type != "none":
        prompt = f"Create a {meal_type} meal with {carbs}g carbs, {protein}g protein, {fat}g fat, and {calories} calories."
    if cuisine_type and cuisine_type != "none":
        prompt += f" The meal should be {cuisine_type} cuisine."

    payload = {
        "contents": [
            {
                "parts": [{"text": prompt}]
            }
        ]
    }

    headers = {
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(GEMINI_API_URL, headers=headers, json=payload)
        data = response.json()

        if "candidates" in data:
            meal_plan = data["candidates"][0]["content"]["parts"][0]["text"]
            return jsonify({'meal_plan': meal_plan.strip()})
        else:
            return jsonify({'error': "Gemini did not return a valid response."})
    except Exception as e:
        return jsonify({'error': f"Error generating meal plan: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)
